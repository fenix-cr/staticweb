<template>
    <div>
      <div class="d-flex flex-wrap mb-2">
        <b-button :variant="inhabilitar === true ? 'primary' : 'outline-secondary'" @click="inhabilitar = false">
          <span class="d-none d-sm-inline">Edit</span>
          <feather-icon icon="EditIcon" class="d-inline d-sm-none" />
        </b-button>

        <b-button v-if="inhabilitar === false" :variant="inhabilitar === true ? 'primary' : 'primary'" class="ml-1"
          @click="saveChanges">
          <span class="d-none d-sm-inline">Save</span>
          <feather-icon icon="TrashIcon" class="d-inline d-sm-none" />
        </b-button>
      </div>

    <!-- form corporate -->
    <b-form  @on-complete="formSubmitted">
      <b-row>
        <!-- Field: Username -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Contract Name" 
          >
          
            <b-form-input
                 v-model="listClients[0].company_legal_name"
               disabled

            />
          </b-form-group>
        </b-col>


        <!-- Field: Email -->
        <b-col md="4">
              <b-form-group
                  label="Expiration Date" for="ExpirationDate"
              >
                
                  <b-form-datepicker
                  id="ExpirationDate"
                      v-model="listClients[0].coporate_account_rate.ExpirationDate" :disabled="inhabilitar === true"
                      :min="min"
                      locale="en"
                      placeholder="0/00/0000"
                     
                  />
                  
               
            </b-form-group>
        </b-col>

<!-- Field: Gender -->
      <b-col cols="12" md="6" lg="4" class="mb-2">
        <label for="Sedan_Base_EachWay"
          >Base Each Way 2 <span class="text-danger">*</span></label
        >
        <b-form-input id="Sedan_Base_EachWay" v-model="BaseEachWay" />
      </b-col>


      </b-row>
      <div class="d-flex mt-2">
          <feather-icon icon="TruckIcon" size="19" />
          <h4 class="mb-0 ml-50">
            Sedan
          </h4>
        </div>
      <b-row class="mt-1">
        <!-- Field: Email -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Base Each Way "
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.Sedan_Base_EachWay" :disabled="inhabilitar === true"
             
            />
          </b-form-group>
        </b-col>

        <!-- Field: Email -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Mileage"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.Sedan_Mileage" :disabled="inhabilitar === true"
               
            />
          </b-form-group>
        </b-col>

         <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Wait Time per hour"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.Sedan_WaitTimeHour" :disabled="inhabilitar === true"
               
            />
          </b-form-group>
        </b-col>


      </b-row>

       <b-row class="mt-1">
        <!-- Field: Email -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Cancellation"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.Sedan_Cancellation" :disabled="inhabilitar === true"

            />
          </b-form-group>
        </b-col>

        <!-- Field: Email -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Minimum Miles"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.Sedan_MinimumMileage" :disabled="inhabilitar === true"
            />
          </b-form-group>
        </b-col>

         <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Minimum Amount One Way"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.Sedan_MinimumPrice" 
                :disabled="inhabilitar === true"
            />
          </b-form-group>
        </b-col>
      </b-row>

       <div class="d-flex mt-2">
          <feather-icon icon="TruckIcon" size="19" />
          <h4 class="mb-0 ml-50">
            Wheelchair Van 
          </h4>
        </div>
      <b-row class="mt-1">
        <!-- Field: Email -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Base Each Way "
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.WheelchairVan_Base_EachWay" :disabled="inhabilitar === true"

            />
          </b-form-group>
        </b-col>

        <!-- Field: Email -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Mileage"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.WheelchairVan_Mileage" :disabled="inhabilitar === true"
            />
          </b-form-group>
        </b-col>

         <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Wait Time per hour"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.WheelchairVan_WaitTimeHour" :disabled="inhabilitar === true"
               
            />
          </b-form-group>
        </b-col>


      </b-row>

       <b-row class="mt-1">
        <!-- Field: Email -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Cancellation"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.WheelchairVan_Cancellation" :disabled="inhabilitar === true"

            />
          </b-form-group>
        </b-col>

        <!-- Field: Email -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Minimum Miles"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.WheelchairVan_MinimumMileage" :disabled="inhabilitar === true"
            />
          </b-form-group>
        </b-col>

        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Minimum Amount One Way"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.WheelchairVan_MinimumPrice" :disabled="inhabilitar === true"
            />
          </b-form-group>
        </b-col>
      </b-row>
    <div class="d-flex mt-2">
          <feather-icon icon="TruckIcon" size="19" />
          <h4 class="mb-0 ml-50">
            Gurney Van
          </h4>
        </div>
      <b-row class="mt-1">
        <!-- Field: Email -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Base Each Way "
          >
            <b-form-input
                 v-model="listClients[0].coporate_account_rate.GurneyVan_Base_EachWay" :disabled="inhabilitar === true"

            />
          </b-form-group>
        </b-col>

        <!-- Field: Email -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Mileage"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.GurneyVan_Mileage" :disabled="inhabilitar === true"
            />
          </b-form-group>
        </b-col>

         <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Wait Time per hour"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.GurneyVan_WaitTimeHour" :disabled="inhabilitar === true"
               
            />
          </b-form-group>
        </b-col>


      </b-row>

       <b-row class="mt-1">
        <!-- Field: Email -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Cancellation"
          >
            <b-form-input
                 v-model="listClients[0].coporate_account_rate.GurneyVan_Cancellation" :disabled="inhabilitar === true"

            />
          </b-form-group>
        </b-col>

        <!-- Field: Email -->
        <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Minimum Miles"
          >
            <b-form-input
                v-model="listClients[0].coporate_account_rate.GurneyVan_MinimumMileage" :disabled="inhabilitar === true"
            />
          </b-form-group>
        </b-col>

         <b-col
            cols="12"
            md="4"
        >
          <b-form-group
              label="Minimum Amount One Way"
          >
           
            <b-form-input
                v-model="listClients[0].coporate_account_rate.GurneyVan_MinimumPrice" :disabled="inhabilitar === true"
            />
            
          </b-form-group>
        </b-col>
      </b-row>


    </b-form>

  </div>
</template>

<script>
import {BRow, BCol, BCard, BImg, BButton, BFormGroup,  BFormDatepicker, BFormInput, BTabs, BTab, BCardText, BAlert,} from 'bootstrap-vue'
import UserProfileClientCorporateAcount from '@core/components/CA/UserProfileClientCorporateAcount'
import UserEditTabInformation from "@core/components/user/UserEditTabInformation";


/* eslint-disable global-require */
export default {
  components: {
    BRow,
    BCol,
    BCard,
    BImg,
    BButton,
    BFormGroup,
    BFormInput,
    BFormDatepicker,
    BTabs,
    BTab,
    BCardText,
    BAlert,

    //componente
    UserProfileClientCorporateAcount,
    UserEditTabInformation,
    
  },
  name: 'DetailsClientsCorporateAccount',
  data() {
    const now = new Date()
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    // 15th two months prior
    const minDate = new Date(today)
    minDate.setMonth(minDate.getMonth() - 1)
    minDate.setDate(15)
    // 15th in two months
    const maxDate = new Date(today)
    maxDate.setMonth(maxDate.getMonth() + 2)
    maxDate.setDate(15)
    return {
      infomation: '',
      fecha: '',
      min: minDate,
      inhabilitar: true,
      idCA: 0,
    
      
      infoPago: {},

      listClients: {
        GurneyVan_Base_EachWay: '',
      }
    }
  },

  methods: {
     getClientes() {
      this.$swal({
        title: 'Please, wait...',
        didOpen: () => {
          this.$swal.showLoading()
        },
      })
      this.idCA = parseInt(this.$route.params.id);
      this.$http.get(`/admin/panel/ca/${this.idCA}/contractlist`).then((response) => {

        this.listClients = response.data.data.reverse();
       // console.log( this.listClients);
        this.$swal.close();
      }).catch((res) => console.log(res.data))
    },


    saveChanges() {
      this.formSubmitted()
    },
    formSubmitted() {
      
      this.idCA = parseInt(this.$route.params.id);
     this.$http.post(`/admin/panel/ca/${this.idCA}/AddContractlist`, this.listClients[0])
        .then((res) => {
          console.log(this.listClients);
          if (res.data.status === 200) {
            this.$swal({
              title: "Record modified successfully",
              icon: 'success',
              customClass: {
                confirmButton: 'btn btn-primary',
              },
              buttonsStyling: false,
            })
            this.inhabilitar = true;
          } else {
            this.$swal({
              title: res.data.message,
              icon: 'error',
              customClass: {
                confirmButton: 'btn btn-primary',
              },
              buttonsStyling: false,
            })
          }
        })
        .catch((res) => {
          console.log(res)
          this.$swal({
            title: res.message,
            icon: 'error',
            customClass: {
              confirmButton: 'btn btn-primary',
            },
            buttonsStyling: false,
          })
        })
    },

    
  }
  ,
  mounted() {

    this.getClientes();
   
       console.log( this.listClients);
    

  }
  ,
  created() {
  }
  ,
}
/* eslint-disable global-require */
</script>

<style lang="scss">
@import '@core/scss/vue/pages/page-profile.scss';

.name-corporative {
  margin-left: 15px;
  font-weight: bold;
  font-size: 1.1rem;
}
</style>
